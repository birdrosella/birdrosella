document.addEventListener('DOMContentLoaded', function () {
 
  let typed = new Typed(".auto-type", {
    strings: ["a Student", "so much more..."],
    typeSpeed: 150,
    backSpeed: 150,
    loop: true
    
  });
  
});